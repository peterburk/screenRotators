/*
* main.m
* © 2008 Axiotron, Inc. 
* 
* Developed by Peter Burkimsher using code from Amit Singh's fb-rotate.c, included in "Mac OS X Internals".
* From the website http://www.osxbook.com/book/src/
* "The source is being made available "as is" under the GNU General Public License (GPL)."
* 
* To Do:
* • Applescript support: http://www.macdevcenter.com/pub/a/mac/2002/02/22/applescript.html?page=1
* 
*/

//#include <getopt.h>
//#include <IOKit/graphics/IOGraphicsLib.h>

// Application services are required for everything: 
#include <ApplicationServices/ApplicationServices.h>
#include <Foundation/NSString.h>
#include <Foundation/NSAppleScript.h>
#include <Foundation/NSAppleEventDescriptor.h>
   
#define MAX_DISPLAYS 16

// currentAngle keeps track of the angle of rotation the display is currently in.
long currentAngle = 0;
// devMode is a boolean to enable additional rotations in the drop-down list. 
bool devMode = false;

// kIOFBSetTransform comes from <IOKit/graphics/IOGraphicsTypesPrivate.h>
// in the source for the IOGraphics family. 
enum {
    kIOFBSetTransform = 0x00000400,
};

/*
* angle2options converts an angle into a bit stream to pass to IOServiceRequestProbe.
* @param long angle: the angle in degrees (0 ≤ angle < 360)
* @return IOOptionBits: the bit stream to pass to the IOServiceRequestProbe
*/
IOOptionBits
angle2options(long angle)
{
    // Define an array of four bit streams for each transformation: normal, right, upside down, and left.
	// kIOFBSetTransform was set as an enum at the start of this class.
	// | is a logical OR
	// kIOScaleRotate* are values from Apple's IOGraphics family.
	// << is a bit shift operator, shifting the result of the OR operation by MAX_DISPLAYS bits
	// MAX_DISPLAYS is a global variable set at the start of this class.
	static IOOptionBits anglebits[] = {
               (kIOFBSetTransform | (kIOScaleRotate0)   << MAX_DISPLAYS),
               (kIOFBSetTransform | (kIOScaleRotate90)  << MAX_DISPLAYS),
               (kIOFBSetTransform | (kIOScaleRotate180) << MAX_DISPLAYS),
               (kIOFBSetTransform | (kIOScaleRotate270) << MAX_DISPLAYS)
           };
	
	// Rotation is limited to only multiples of 90º; other angles are mapped to a rotation reset (0º)
    if ((angle % 90) != 0)
	{
		return anglebits[0];
	}
	
	// If the angle is a valid multiple of 90, find the appropriate bit stream in the anglebits array
    return anglebits[(angle / 90) % 4];
}

/*
* rotate: Rotates the display based on an angle in degrees passed.
* @param long angle: The angle to rotate the display.
*/
void
rotate (long angle)
{
	// An IO service we will be using to apply our commands.
	io_service_t      service;
	// An error we will pass to the terminal if there is trouble rotating.
    CGDisplayErr      displayError;
	// The display ID we wish to rotate. Set to 0 by default, real displays begin at 1.
    CGDirectDisplayID targetDisplay = 0;
	// The options bit stream we pass to the service probe. 
    IOOptionBits      options;
    
    // Get the ID of the display we are using. Included in IOKit framework, not any included files.
	targetDisplay = CGMainDisplayID();
	
	// If we did not read a display ID, exit with an error.
    if (targetDisplay == 0)
	{
		exit(1);
	}
    
	// Derive a bit stream to pass to the service from our input angle.
    options = angle2options(angle);
   
    // Get the I/O Kit service port of the target display.
    // Since the port is owned by the graphics system, we should not destroy it.
    service = CGDisplayIOServicePort(targetDisplay);
    
	// Try rotating the display! Give any errors to displayError. 
    displayError = IOServiceRequestProbe(service, options);

    // We will get an error if the target display doesn't support the
    // kIOFBSetTransform option for IOServiceRequestProbe()
    if (displayError != kCGErrorSuccess) {
        exit(1);
    } else
	{
		// If we did not get an error, update our currentAngle variable. 
		currentAngle = angle;
	}
}

/*
* getAngle: Accessor method for the currentAngle variable.
* @return long: The current angle of rotation.
*/
long getAngle()
{
	return(currentAngle);
}


/*
* getAngle: Accessor method for the devMode variable.
* @return bool: Whether we are running in developer mode.
*/
bool getMode()
{
	return(devMode);
}

/*
* setMode: Mutator method for the devMode variable.
* Reads the process list to check the name of our application.
*/
void setDevMode()
{
	// Find whether we're QuickFlip or QuickFlipDev
	NSString *devScript = @"return (do shell script \"ps -ax\") contains \"QuickFlipDev.app\"";
	NSAppleScript *script = [[NSAppleScript alloc] initWithSource:devScript];
	NSAppleEventDescriptor *result;
	result = [script executeAndReturnError:nil];
	devMode = [result booleanValue];
}

/*
* disableMouse: Disassociates the mouse and cursor position.
*/
void disableMouse ()
{
	CGAssociateMouseAndMouseCursorPosition (FALSE);
}

/*
* enableMouse: Associates the mouse and cursor position.
*/
void enableMouse ()
{
	CGAssociateMouseAndMouseCursorPosition (TRUE);
}

/*
* disableClicks: Starts the transparent window.
*/
void disableClicks ()
{
	// Not yet coded!
}

/*
* forceFrontmost: Keeps QuickFlip the frontmost application.
*/
void forceFrontmost ()
{
	// The AppleScript didn't work fast enough
	NSString *frontScript = @"tell application \"QuickFlipDev\" \n activate \n end tell";
	NSAppleScript *script = [[NSAppleScript alloc] initWithSource:frontScript];

	[script executeAndReturnError:nil];
}

/*
* main: Initialise the application.
* @param int argc, char **argv: Initialisation variables
* @return int: Any error codes generated.
*/
int main(int argc, char **argv)
{
    setDevMode();
	enableMouse();
	// Rotates the display to 0º: helpful when debugging, and keeps the currentAngle variable correct.
	rotate(90);
	// Start up the application using the standard variables. 
	//return NSApplicationMain(argc,  (const char **) argv);
}