/*
* Controller.m
* © 2008 Axiotron, Inc.
* 
* Built by Peter Burkimsher using modified code from Paul Kim's StatusItemTester, 
* http://www.noodlesoft.com/blog/2007/02/17/noodlelabs-super-duper-menu-bar-icon-tester-thing/
* 
* This class creates the interactive menu bar element.
*/

#import "Controller.h"

@implementation Controller

// Two rotations cannot be done immediately without crashing, therefore we wait sleepTime seconds.
int sleepTime = 6;

/*
* Dealloc: Removes the menu bar item.
*/
- (void)dealloc
{
	// Tell the menu bar to remove our icon, and tell it to release
	[[NSStatusBar systemStatusBar] removeStatusItem:quickFlipMenu];
	[quickFlipMenu release];
	
	[super dealloc];
}

/* 
* statusItem: Creates the menu bar item.
* @return id: Our menu item.
*/
- (id)statusItem
{
	// If there is a menu item already defined, skip to the end and return the existing item.
	if (quickFlipMenu == nil)
	{
		// Make it a variable length icon so it is easier to change our icon as desired.
		quickFlipMenu = [[[NSStatusBar systemStatusBar] statusItemWithLength:NSVariableStatusItemLength] retain];
		// Tell it which image to use by default.
		[quickFlipMenu setImage:[NSImage imageNamed:@"Display"]];
		// Enable highlighting: it appears selected when the drop-down menu is shown.
		[quickFlipMenu setHighlightMode:YES];
		
		// The NSMenu is the drop-down list that leaves the NSStatusItem menu extra.
		NSMenu		*menu;
		
		// We don't need to give it a title.
		menu = [[NSMenu alloc] initWithTitle:@""];
		// Always show the Flip option, which runs the Flip IBAction.
		[menu addItemWithTitle:@"Flip" action:@selector(flip:) keyEquivalent:@""];
		
		// If we're in developer mode, add a host of other options.
		if (getMode() == true)
		{
			[menu addItemWithTitle:@"0º" action:@selector(normal:) keyEquivalent:@""];
			[menu addItemWithTitle:@"90º" action:@selector(right:) keyEquivalent:@""];
			[menu addItemWithTitle:@"180º" action:@selector(upside:) keyEquivalent:@""];
			[menu addItemWithTitle:@"270º" action:@selector(left:) keyEquivalent:@""];
			[menu addItemWithTitle:@"Repair" action:@selector(repair:) keyEquivalent:@""];
			[menu addItemWithTitle:@"Disable Mouse" action:@selector(mouseOff:) keyEquivalent:@""];
			[menu addItemWithTitle:@"Enable Mouse" action:@selector(mouseOn:) keyEquivalent:@""];
			[menu addItemWithTitle:@"Disable Clicks" action:@selector(clicksOff:) keyEquivalent:@""];
		}
		
		// Always show the Quit option, which runs the standard Terminate action.
		[menu addItemWithTitle:@"Quit" action:@selector(terminate:) keyEquivalent:@""];
		
		// Add the menu to the NSStatusItem
		[quickFlipMenu setMenu:menu];
		[menu release];		
	}
	
	// Pass the menu bar extra back to the calling process.
	return quickFlipMenu;
}

/* 
* normal: Rotates the display to 0º, and sets the regular icon.
*/
-(IBAction)normal:(id)sender
{
		[quickFlipMenu setImage:[NSImage imageNamed:@"Display"]];
		rotate(0);
}

/* 
* right: Rotates the display to 90º, and sets the regular icon.
*/
-(IBAction)right:(id)sender
{
		[quickFlipMenu setImage:[NSImage imageNamed:@"Display"]];
		rotate(90);
}

/* 
* left: Rotates the display to 270º, and sets the regular icon.
*/
-(IBAction)left:(id)sender
{
		[quickFlipMenu setImage:[NSImage imageNamed:@"Display"]];
		rotate(270);
}

/* 
* upside: Rotates the display to 180º, and sets the flipped icon.
*/
-(IBAction)upside:(id)sender
{
		[quickFlipMenu setImage:[NSImage imageNamed:@"DisplayFlipped"]];
		rotate(180);
}

/* 
* repair: Rotates the display to 90º and back again, repairing the calibration.
*/
-(IBAction)repair:(id)sender
{
		long angle = getAngle();
		rotate(90);
		sleep(sleepTime);
		rotate(angle);
}

/* 
* mouseOff: Disables the mouse.
*/
-(IBAction)mouseOff:(id)sender
{
	disableMouse();
	forceFrontmost();
}


/* 
* mouseOn: Enables the mouse.
*/
-(IBAction)mouseOn:(id)sender
{
	enableMouse();
}

/* 
* clicksOff: Disables mouse clicks.
*/
-(IBAction)clicksOff:(id)sender
{
	disableClicks();
}

/* 
* flip: Reads the angle variable set by the rotate method, and rotates accordingly.
* The repair function is already built in to these calls, and the required delay is coded. 
*/
-(IBAction)flip:(id)sender
{
	long angle = getAngle();
	
	// If we are at 180º, we rotate 0º via 90º.
	if (angle == 180)
	{
		[quickFlipMenu setImage:[NSImage imageNamed:@"Display"]];
		rotate(90);
		sleep(sleepTime);
		rotate(0);
	}
	
	// If we are at 0º, we rotate 180º via 90º.
	if (angle == 0)
	{
		[quickFlipMenu setImage:[NSImage imageNamed:@"DisplayFlipped"]];
		rotate(90);
		sleep(sleepTime);
		rotate(180);
	}
	
	// If we are at 90º, we revert it to our normal view rather than flipping.
	if (angle == 90)
	{
		[quickFlipMenu setImage:[NSImage imageNamed:@"Display"]];
		rotate(0);
	}
	
}

// application: Gets the application object.
// @return NSApplication: The application
- (NSApplication *)application
{
	return NSApp;
}

@end
