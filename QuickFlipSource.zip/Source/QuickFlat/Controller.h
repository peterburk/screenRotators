/* 
* Controller.h
* © 2008 Axiotron, Inc.
* 
* Built by Peter Burkimsher using modified code from Paul Kim's StatusItemTester, 
* http://www.noodlesoft.com/blog/2007/02/17/noodlelabs-super-duper-menu-bar-icon-tester-thing/
* 
* This class defines an object, quickFlipMenu, an NSStatusItem with which we interact.
*/

#import <Cocoa/Cocoa.h>

@interface Controller : NSObject
{
	NSStatusItem		*quickFlipMenu;
}

- (id)statusItem;
- (NSApplication *)application;

@end
